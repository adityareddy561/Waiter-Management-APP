package com.example.waitermanagementapp1;


public class product{
    private String itemname;
    private int quantity;
    private int price;


    public product(String itemname, Integer quantity, Integer price) {
        this.itemname = itemname;
        this.quantity = quantity;
        this.price = price;
    }


    public String getItemname() {
        return itemname;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public Integer getPrice() {
        return price;
    }

}

