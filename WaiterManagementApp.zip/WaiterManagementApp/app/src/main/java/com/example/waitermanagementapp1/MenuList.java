package com.example.waitermanagementapp1;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MenuList extends AppCompatActivity{

    RecyclerView recyclerView;
    ProductAdapter padapter;
    List<product> productList;
    DatabaseHelper myDB;
    EditText ed2, ed3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getdata();

        myDB = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerview2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        padapter = new ProductAdapter(this, productList, myDB);
        recyclerView.setAdapter(padapter);


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_item, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.submit) {
            Intent intent = new Intent(this, Bill.class);
            startActivity(intent);
        }
        if (id == R.id.additem) {
            AlertDialog.Builder abuilder = new AlertDialog.Builder(MenuList.this);
            abuilder.setTitle("Addition");
            abuilder.setMessage("Enter the dish name");
            LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
            View v = inflater.inflate(R.layout.dish, null);
            abuilder.setView(v);

            ed2 = v.findViewById(R.id.editText2);
            ed3 = v.findViewById(R.id.editText3);
            abuilder.setPositiveButton("ADD", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    productList.add(new product(ed2.getText().toString(), 0, Integer.parseInt(ed3.getText().toString())));
                    adddata();
                    padapter.notifyDataSetChanged();
                }
            });
            abuilder.setNegativeButton("NO", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            abuilder.show();
        }

        return super.onOptionsItemSelected(item);
    }

    public void adddata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(productList);
        editor.putString("menu", json);
        editor.apply();
    }

    public void getdata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("menu", null);
        Type type = new TypeToken<List<product>>(){
        }.getType();
        productList = gson.fromJson(json, type);
        if (productList == null) {
            productList = new ArrayList<>();
        }
    }
}
