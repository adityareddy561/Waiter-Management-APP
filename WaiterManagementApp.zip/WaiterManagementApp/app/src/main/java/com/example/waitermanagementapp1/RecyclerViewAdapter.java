package com.example.waitermanagementapp1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

    private Context mcontext;
    private List<item> itemList;

    public RecyclerViewAdapter(Context mcontext, List<item> itemList) {
        this.mcontext = mcontext;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mcontext);
        View view = inflater.inflate(R.layout.list_item, null);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final item items = itemList.get(position);
        holder.imageName.setText(items.getTitle());
        holder.image.setImageDrawable(mcontext.getResources().getDrawable(items.getImage()));
        holder.imageName.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mcontext, MenuList.class);
                mcontext.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        CircleImageView image;
        TextView imageName;
        ImageView im2;
        LinearLayout ll;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.imageView6);
            imageName = itemView.findViewById(R.id.textView4);
            im2 = itemView.findViewById(R.id.imageView4);
            ll = itemView.findViewById(R.id.parent_layout);
            im2.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            final int pos = getLayoutPosition();
            if (v.getId() == R.id.imageView4) {

                AlertDialog.Builder abuilder = new AlertDialog.Builder(mcontext);
                abuilder.setTitle("Remove");
                abuilder.setMessage("Do you want to delete the table?");
                abuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        itemList.remove(pos);
                        notifyDataSetChanged();
                    }
                });
                abuilder.setNegativeButton("No", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                abuilder.show();
            }
        }
    }
}
