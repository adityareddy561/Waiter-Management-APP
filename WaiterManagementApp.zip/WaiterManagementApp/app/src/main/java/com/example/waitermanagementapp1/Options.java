package com.example.waitermanagementapp1;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class Options extends AppCompatActivity{

    RecyclerView recyclerView;
    RecyclerViewAdapter adapter;
    List<item> itemList;
    TextView tv;
    EditText ed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        loaddata();
        tv = findViewById(R.id.textView4);
        recyclerView = findViewById(R.id.recyclerview1);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                AlertDialog.Builder abuilder = new AlertDialog.Builder(Options.this);
                abuilder.setTitle("Addition");
                abuilder.setMessage("Do you want to add table?");
                LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
                View dview = inflater.inflate(R.layout.addition, null);
                abuilder.setView(dview);

                ed = dview.findViewById(R.id.editText);
                abuilder.setPositiveButton("ADD", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        itemList.add(new item(R.drawable.rtable, "Table " + ed.getText().toString()));
                        savedata();
                        adapter.notifyDataSetChanged();

                    }
                });
                abuilder.setNegativeButton("No", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                abuilder.show();

            }
        });
        adapter = new RecyclerViewAdapter(this, itemList);
        recyclerView.setAdapter(adapter);
    }

    public void open(View view) {
        Intent intent = new Intent(this, MenuList.class);
        startActivity(intent);
    }


    public void savedata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(itemList);
        editor.putString("table list", json);
        editor.apply();
    }

    public void loaddata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("table list", null);
        Type type = new TypeToken<List<item>>(){
        }.getType();
        itemList = gson.fromJson(json, type);
        if (itemList == null) {
            itemList = new ArrayList<>();
        }
    }
}


