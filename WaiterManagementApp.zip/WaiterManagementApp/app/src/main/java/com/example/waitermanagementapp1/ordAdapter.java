package com.example.waitermanagementapp1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ordAdapter extends RecyclerView.Adapter<ordAdapter.ViewHolder>{

    private Context mctx;
    private List<product> orderList;


    public ordAdapter(Context mctx, List<product> orderList) {
        this.mctx = mctx;
        this.orderList = orderList;
    }


    @NonNull
    @Override
    public ordAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mctx);
        View view = inflater.inflate(R.layout.order, parent, false);
        ordAdapter.ViewHolder holder = new ordAdapter.ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ordAdapter.ViewHolder holder, int position) {
        product orders = orderList.get(position);
        holder.txt1.setText(orders.getItemname());
        holder.txt2.setText(String.valueOf(orders.getQuantity()));
        holder.txt3.setText(String.valueOf(orders.getPrice()));
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView txt1, txt2, txt3;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt1 = itemView.findViewById(R.id.textView9);
            txt2 = itemView.findViewById(R.id.textView10);
            txt3 = itemView.findViewById(R.id.textView11);

        }
    }
}
