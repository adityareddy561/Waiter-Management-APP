package com.example.waitermanagementapp1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHoder>{


    private DatabaseHelper myDB;
    private Context mctxt;
    private List<product> productList;
    int no_of_items = 0;


    public ProductAdapter(Context mctxt, List<product> productList, DatabaseHelper myDB) {
        this.mctxt = mctxt;
        this.productList = productList;
        this.myDB = myDB;
    }

    @NonNull
    @Override
    public ViewHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mctxt);
        View view = inflater.inflate(R.layout.item_list, null);
        ViewHoder holder = new ViewHoder(view);
        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoder holder, int position) {

        product products = productList.get(position);
        holder.txt1.setText(products.getItemname());
        holder.txt2.setText(String.valueOf(products.getQuantity()));
        holder.txt3.setText(String.valueOf(products.getPrice()));
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ViewHoder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView txt1, txt2, txt3;
        Button bt1, bt2, bt3;
        ImageView im1;

        public ViewHoder(@NonNull View itemView) {
            super(itemView);
            txt1 = itemView.findViewById(R.id.textView5);
            txt2 = itemView.findViewById(R.id.textView8);
            txt3 = itemView.findViewById(R.id.textView12);
            im1 = itemView.findViewById(R.id.imageView2);
            bt1 = itemView.findViewById(R.id.button);
            bt2 = itemView.findViewById(R.id.button2);
            bt3 = itemView.findViewById(R.id.button3);
            im1.setOnClickListener(this);
            bt1.setOnClickListener(this);
            bt2.setOnClickListener(this);
            bt3.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            final int pos = getLayoutPosition();
            if (v.getId() == R.id.button3) {

                String newEntry = txt1.getText().toString();
                Integer newEntry1 = Integer.parseInt(txt2.getText().toString());
                Integer newEntry2 = Integer.parseInt(txt3.getText().toString());
                Integer c = newEntry1 * newEntry2;
                myDB.adddata(newEntry, newEntry1, c);
                txt2.setText(String.valueOf(0));
                Toast.makeText(mctxt, "Added " + newEntry, Toast.LENGTH_SHORT).show();

            }

            if (v.getId() == R.id.imageView2) {

                AlertDialog.Builder abuilder = new AlertDialog.Builder(mctxt);
                abuilder.setTitle("Remove");
                abuilder.setMessage("Do you want to delete the dish?");
                abuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        productList.remove(pos);
                        notifyDataSetChanged();
                    }
                });
                abuilder.setNegativeButton("No", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                abuilder.show();
            }
            if (v.getId() == R.id.button2) {
                no_of_items = Integer.parseInt(txt2.getText().toString());
                increase(no_of_items);

            }
            if (v.getId() == R.id.button) {
                no_of_items = Integer.parseInt(txt2.getText().toString());
                decrease(no_of_items);
            }
        }

        public void increase(int y) {
            y = y + 1;
            display(y);

        }

        public void decrease(int b) {
            b = b - 1;
            if (b < 0) {
                b = 0;
                display(b);
            } else {
                display(b);
            }
        }

        public void display(int number) {
            txt2.setText("" + number);
        }
    }


}
