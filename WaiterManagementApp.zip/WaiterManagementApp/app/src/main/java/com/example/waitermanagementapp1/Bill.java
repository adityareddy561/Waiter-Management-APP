package com.example.waitermanagementapp1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Bill extends AppCompatActivity{

    DatabaseHelper myDB;
    RecyclerView recyclerView;
    ordAdapter adapter;
    List<product> orderList;
    TextView t14;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);


        recyclerView = findViewById(R.id.recyclerview4);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderList = new ArrayList<>();

        myDB = new DatabaseHelper(this);


        Cursor data = myDB.getListContents();
        if (data.getCount() == 0) {

        } else {
            while (data.moveToNext()) {
                int a = data.getInt(1) * data.getInt(2);
                orderList.add(new product(data.getString(0), data.getInt(2), data.getInt(1)));
                adapter = new ordAdapter(this, orderList);
                recyclerView.setAdapter(adapter);
            }
        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.order, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.bill) {
            AlertDialog.Builder abuilder = new AlertDialog.Builder(Bill.this);
            abuilder.setTitle("Bill");
            LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
            View v = inflater.inflate(R.layout.finalbill, null);
            abuilder.setView(v);
            t14 = v.findViewById(R.id.textView14);
            final Cursor data1 = myDB.calculate();
            if (data1.moveToFirst()) {

                int total = data1.getInt(data1.getColumnIndex("Total"));
                t14.setText(String.valueOf(total));
            }


            abuilder.setPositiveButton("YES", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    myDB.deleteRecord();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }

            });
            abuilder.setNegativeButton("NO", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            abuilder.show();
        }
        return super.onOptionsItemSelected(item);
    }
}